# Ale Healthcare Institute Website

This folder is ready for GitHub Pages.

## Files
- `index.html`
- `styles.css`

## How to upload
1. Create a GitHub repository named exactly as your domain, for example:
   `yourdomain.com`
2. Upload both files to the main repository.
3. Go to **Settings > Pages**
4. Under **Build and deployment**, choose:
   - Source: **Deploy from a branch**
   - Branch: **main**
   - Folder: **/root**
5. Save.

## Connect your custom domain
In **Settings > Pages**, enter your domain name.

Then add these DNS records where you bought your domain:

### A records
- 185.199.108.153
- 185.199.109.153
- 185.199.110.153
- 185.199.111.153

### CNAME
- Name: `www`
- Value: yourdomain.com

## Replace these placeholders in index.html
- `yourschool@email.com`
- `(000) 000-0000`
- `Hackensack, New Jersey`

You can also edit the program list, tuition, and wording anytime.
